# EMA Türkçe TTS — Android APK başlangıç projesi

Bu paket, EMA Lightning web demosunu Android uygulaması içinde açan basit bir WebView uygulaması ve GitHub Actions ile APK derleme iş akışı içerir. **Bu ZIP'in kendisi APK değildir.** Bu çalışma ortamında Android SDK bulunmadığından APK'yı burada derleyip test edemedim.

## Önce telefonda dene

EMA Lightning demosu: https://ema-lightning-web.vercel.app/

## APK oluşturma (Android Studio kurmadan)

1. GitHub'da kendi hesabında yeni bir **Public** depo oluştur.
2. Bu ZIP'i aç ve içindeki dosya/klasörleri deponun ana dizinine yükle. `.github` klasörü de dahil olmalı.
3. GitHub deposunda **Actions** sekmesine gir.
4. Soldan **Build Android APK** iş akışını seç.
5. **Run workflow** düğmesine bas ve derlemenin bitmesini bekle.
6. Başarılı çalışmanın altındaki **Artifacts** bölümünden `EMA-Turkce-TTS-debug-apk` dosyasını indir.
7. İndirdiğin ZIP'i aç; içindeki `app-debug.apk` dosyasını telefona gönderip kur. Android, bilinmeyen kaynaktan kurulum izni isteyebilir.

## Bilmen gerekenler

- Uygulama web demosunu açar; bu nedenle internet bağlantısı gerekir. Web demosunun önbelleği bazı dosyaları saklayabilir ama tam çevrimdışı çalışma garanti edilmez.
- Bu başlangıç sürümünde uzun metni otomatik parçalara ayırma, özel pitch/kalınlık kontrolleri, noktalama duraklamaları ve WAV birleştirme özellikleri henüz ekli değildir.
- APK'nın derlenmesi GitHub Actions tamamlanınca doğrulanmış olur; telefonunda kurulum ve ses üretimi ayrıca test edilmelidir.
- Kaynak proje: https://github.com/ozcancelik/ema-lightning-web
- ONNX model deposu: https://huggingface.co/ozcancelik/ema-lightning-onnx
